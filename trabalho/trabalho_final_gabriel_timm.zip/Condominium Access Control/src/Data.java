public class Data {
  private String data;

  public Data(String data) {
    this.data = data;
  }

  public String toString() {
    return data;
  }
}
